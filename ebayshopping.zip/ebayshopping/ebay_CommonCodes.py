import time
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.common.by import By
import selenium.webdriver.support.ui as ui
from datetime import datetime
from robot.libraries.BuiltIn import BuiltIn
from ebay_Testsuite import TestSuite
from robot.api import logger

html_pass = '<b style="color:green">PASS</b>'
html_fail = '<b style="color:red">FAIL</b>'

class ebay_CommonCodes():
    def __init__(self,**kwargs):
        self.objSuite = TestSuite('001')
        self.chrome_driver = ''
        if 'driver' in kwargs:
            self.chrome_driver = kwargs['driver']
        self.ebay_url = self.objSuite.ebay_url
        self.search_br = self.objSuite.search_br
        self.result_kw = self.objSuite.result_kw
        self.ebay_logo = self.objSuite.ebay_logo
        self.cond_value = self.objSuite.cond_value
        self.price_value = self.objSuite.price_value
        self.prod_name = self.objSuite.prod_name
        self.sellinfo_proddetail = self.objSuite.sellinfo_proddetail
        self.add_cart = self.objSuite.add_cart
        self.prot_plan = self.objSuite.prot_plan
        self.thank_btn = self.objSuite.thank_btn
        self.ck_title = self.objSuite.ck_title
        self.cond_value1 = self.objSuite.cond_value1
        self.price_value1 = self.objSuite.price_value1
        self.prod_name1 = self.objSuite.prod_name1
        self.sellinfo_shopcart = self.objSuite.sellinfo_shopcart
        self.search_item = self.objSuite.search_item
        self.nxt_btn = self.objSuite.nxt_btn
        self.inch_search = self.objSuite.inch_search
        self.itm_list = self.objSuite.itm_list
        self.robot_env = BuiltIn()


# Search for Sony TV and verify if results for Sony TV is displayed - Product Search
    def product_search_chrome(self):
        try:
            # import sys, pdb;
            # pdb.Pdb ( stdout=sys.__stdout__ ).set_trace ()
            elem = self.chrome_driver.find_element_by_xpath(self.search_br)
            elem.send_keys(self.search_item)
            elem.send_keys(Keys.RETURN)
            self.wait = WebDriverWait(self.chrome_driver,10)
            verify_search_result = self.wait.until(
                EC.visibility_of_element_located((By.XPATH, self.result_kw)))
            if verify_search_result:
                logger.info("\t <b><h2>     PRODUCT SEARCH SUCCESSFUL : %s </h2></b>" % html_pass, html=True)
            self.robot_env.log_to_console("Object for searched element is :" + str(verify_search_result))
        except Exception as e:
            self.robot_env.log_to_console("PRODUCE SEARCH FAILED", str(e))
            logger.info("\t <b><h2>     PRODUCE SEARCH FAILED : </h2></b> %s" % html_fail, html=True)
            time.sleep(3)
            self.chrome_driver.driver.close()



# Search for 50-60 inch tab and click.
    def choose_category_chrome(self):
        try:
            import sys, pdb;
            pdb.Pdb(stdout=sys.__stdout__).set_trace()
            time.sleep(3)
            flag = 0
            button_elem = self.chrome_driver.find_element_by_xpath(self.inch_search)
            self.robot_env.log_to_console('Object for 50" - 60" button element is :' + str(button_elem))
            while (flag == 0):
                if button_elem.is_displayed():
                    button_elem.click()
                    self.robot_env.log_to_console("Button 50-60 inch clicked successfully")
                    flag = 1
                else:
                    self.chrome_driver.find_element_by_css_selector(self.nxt_btn).click()
        except Exception as e:
            self.robot_env.log_to_console("CHOOSE CATEGORY FAILED" , str(e))
            logger.info("\t <b><h2>     CHOOSE CATEGORY FAILED : %s </h2></b>" % html_fail, html=True)
            time.sleep(3)
            self.chrome_driver.driver.close()



# Check if new list is displayed and if first item has text 'sony' and 'tv' - Select Product
    def select_product_chrome(self):
        try:
            # import sys, pdb;
            # pdb.Pdb ( stdout=sys.__stdout__ ).set_trace ()
            time.sleep(3)
            itemlist = self.chrome_driver.find_elements_by_css_selector(self.itm_list)
            time.sleep(3)
            if 'sony' in itemlist[0].text.lower():
                if 'tv' in itemlist[0].text.lower():
                    logger.info("\t <b><h2>     PRODUCT CONTAINS WORD 'SONY' and 'TV' : %s </h2></b>" % html_pass, html=True)
                    itemlist[0].click()
            else:
                logger.info("\t <b><h2>     PRODUCT DOES NOT CONTAINS WORD 'SONY' and 'TV' : %s </h2></b>" % html_fail, html=True)
        except Exception as e:
            self.robot_env.log_to_console("FAILED TO SELECT PRODUCT" , str(e))
            logger.info("\t <b><h2>FAILED TO SELECT PRODUCT : %s </h2></b>" % html_fail, html=True)
            time.sleep(3)
            self.chrome_driver.driver.close()


# Store all the verification details into a dictionary and Add to Cart - Product detail page
    def product_detail_page_chrome(self):
        try:
            wait = WebDriverWait(self.chrome_driver, 10)
            verify_search_result = wait.until(EC.visibility_of_element_located((By.XPATH, self.ebay_logo)))
            if verify_search_result.is_displayed():
                self.prod_detail = {}
                key1 = "Condition"
                key2 = "Price"
                key3 = "Produce Name"
                key4 = "Seller Information"
                value1 = self.chrome_driver.find_element_by_xpath(self.cond_value).text
                value2 = self.chrome_driver.find_element_by_xpath(self.price_value).text
                value2 = str(value2).replace('US ', '')
                value3 = self.chrome_driver.find_element_by_xpath(self.prod_name).text
                value4 = self.chrome_driver.find_element_by_css_selector(self.sellinfo_proddetail).text

                self.prod_detail[key1] = value1
                self.prod_detail[key2] = value2
                self.prod_detail[key3] = value3
                self.prod_detail[key4] = value4
                logger.info("\t <b><h2>     PRODUCT DETAILS CAPTURED SUCCESSFULLY : %s </h2></b>" % html_pass,html=True)
            else:
                logger.info("\t <b><h2>     PRODUCT DETAILS NOT CAPTURED : %s </h2></b>" % html_fail, html=True)
                time.sleep(3)
                self.chrome_driver.close()

        except Exception as e:
            self.robot_env.log_to_console("PRODUCTION VALIDATION FAILED IN PRODUCT DETAIL PAGE" , str(e))
            logger.info("\t <b><h2>     PRODUCTION VALIDATION FAILED IN PRODUCT DETAIL PAGE : %s </h2></b>" % html_fail, html=True)
            time.sleep(3)
            self.chrome_driver.driver.close()


# Check if Condition is empty and proceed to Check out page - Validate Condition
    def validate_condition_parameter_chrome(self):
        try:
            for key, value in self.prod_detail.items():
                if key == 'Condition':
                    if value is None or value == '':
                        logger.info("\t <b><h2>     'CONDITION' IS EMPTY : %s </h2></b>" % html_fail, html=True)
                    else:
                        logger.info("\t <b><h2>     'CONDITION' IS NOT EMPTY : %s </h2></b>" % html_pass, html=True )
            time.sleep(3)
            self.chrome_driver.find_element_by_xpath(self.add_cart).click()

        except Exception as e:
            self.robot_env.log_to_console("CONDITION TYPE VALIDATION FAILED" , str(e))
            logger.info("\t <b><h2>     CONDITION TYPE VALIDATION FAILED : %s </h2></b>" % html_fail, html=True)
            time.sleep(3)
            self.chrome_driver.driver.close()

# handle Protection Plan popup.
    def protection_plan_chrome(self):
        try:
            prot_plan = self.chrome_driver.find_element_by_xpath(self.prot_plan)
            if prot_plan:
                self.robot_env.log_to_console("Handle Protection Plan Popup")
                self.chrome_driver.find_element_by_xpath(self.thank_btn).click
            else:
                self.robot_env.log_to_console("Protection Plan pop is skipped")
        except Exception as e:
            self.robot_env.log_to_console("PROTECTION PLAN NOT HANDLED PROPERLY : ", str(e))
            logger.info("\t <b><h2>     PROTECTION PLAN NOT HANDLED PROPERLY : %s </h2></b>" % html_fail, html=True)
            time.sleep(3)
            self.chrome_driver.driver.close()

# Produce detail validation from Checkout Page.
    def checkout_Page_validation_chrome(self):
        try:
            # import sys, pdb;
            # pdb.Pdb ( stdout=sys.__stdout__ ).set_trace ()
            wait = WebDriverWait(self.chrome_driver, 10)
            verify_search_result = wait.until(EC.visibility_of_element_located((By.XPATH, self.ck_title)))

            if 'Your eBay Shopping Cart' in verify_search_result.text:
                self.prod_detail1 = {}
                key1 = "Condition"
                key2 = "Price"
                key3 = "Produce Name"
                key4 = "Seller Information"
                value1 = self.chrome_driver.find_element_by_xpath(self.cond_value1).text
                # import sys, pdb;
                # pdb.Pdb ( stdout=sys.__stdout__ ).set_trace ()
                value2 = self.chrome_driver.find_element_by_xpath(self.price_value1).text
                value3 = self.chrome_driver.find_element_by_xpath(self.prod_name1).text
                value4 = self.chrome_driver.find_element_by_css_selector(self.sellinfo_shopcart).text

                self.prod_detail1[key1] = value1
                self.prod_detail1[key2] = value2
                self.prod_detail1[key3] = value3
                self.prod_detail1[key4] = value4

                logger.info("\t <b><h2>     PRODUCT VALIDATION SUCCESSFUL : %s </h2></b>" % html_pass, html=True)

            else:
                logger.info("\t <b><h2>     PRODUCT VALIDATION FAILED  IN SHOPPING CART : %s </h2></b>" % html_fail, html=True)
                time.sleep(3)
                self.chrome_driver.close()

        except Exception as e:
            self.robot_env.log_to_console("PRODUCT VALIDATION FAILED  IN SHOPPING CART :" , str(e))
            logger.info("\t <b><h2>     PRODUCT VALIDATION FAILED  IN SHOPPING CART  : %s </h2></b>" % html_fail, html=True)
            time.sleep(3)
            self.chrome_driver.driver.close()

# Validate if Produce details are same in Shopping cart and Produce details page - Product Detail Validation
    def product_detail_validation_chrome(self):
        try:
            # import sys, pdb;
            # pdb.Pdb(stdout=sys.__stdout__).set_trace()
            for keyOne in self.prod_detail:
                for keyTwo in self.prod_detail1:
                    if keyOne == keyTwo:
                        if self.prod_detail[keyOne] == self.prod_detail1[keyTwo]:
                            logger.info("\t <b><h2>     PRODUCE DETAIL IN SHOPPING CART AND PRODUCT DETAIL PAGE MATCHES : %s </h2></b>" % html_pass,html=True)
                        else:
                            logger.info("\t <b><h2>     PRODUCE DETAIL IN SHOPPING CART AND PRODUCT DETAIL PAGE DOES NOT MATCH : %s </h2></b>" % html_fail,html=True)
                        break
        except Exception as e:
            self.robot_env.log_to_console("PRODUCE DETAIL IN SHOPPING CART AND PRODUCT DETAIL PAGE DOES NOT MATCH" , str(e))
            logger.info("\t <b><h2>     PRODUCE DETAIL IN SHOPPING CART AND PRODUCT DETAIL PAGE DOES NOT MATCH : %s </h2></b>" % html_fail, html=True)
            time.sleep(3)
            self.chrome_driver.driver.close()
