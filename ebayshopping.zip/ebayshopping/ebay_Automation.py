import time
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.common.by import By
import selenium.webdriver.support.ui as ui
from datetime import datetime
from ebay_Testsuite import TestSuite
from robot.libraries.BuiltIn import BuiltIn
from robot.api import logger
from ebay_CommonCodes import ebay_CommonCodes
html_pass = '<b style="color:green">PASS</b>'
html_fail = '<b style="color:red">FAIL</b>'


class ebay_Automation(object):
    def __init__(self):
        pass

    def testcase001_initialize(self, testname):
        robot_env = BuiltIn()
        robot_env.log_to_console("****Script Starts Here****")
        robot_env.log_to_console(testname)
        tc = globals()[testname]
        self.tc = tc("001")
        self.tc.initialize()

    def testcase_setup(self):
        self.tc.setup()

    def testcase_test(self):
        self.tc.test()

    def testcase_cleanup(self):
        self.tc.cleanup()


class EBAY_PRODUCT_VALIDATION():
    def __init__(self, testid):
        self.testid = testid

    def initialize(self):
        self.objSuite = TestSuite(self.testid)
        self.robot_env = BuiltIn()
        logger.info("*****************************************************************************************")
        logger.info("self.testid : %s" % self.testid)
        logger.info("*****************************************************************************************")


# initiation of chrome driver and maximising the screen - Landing Page
    def setup(self):
        try:
            if self.testid == "001":
                self.driver = webdriver.Chrome("C:\\Python27\\chromedriver_win32\\chromedriver.exe")
                self.commonobj = ebay_CommonCodes(driver=self.driver)
                if self.driver:
                    logger.info("\t <b><h2>     BROWSER LAUNCHED SUCCESSFULLY : %s </h2></b>" % html_pass, html=True)
                else:
                    logger.info("\t <b><h2>     ERROR LOADING EBAY WEBSITE : %s </h2></b>" % html_fail, html=True)
                self.driver.maximize_window()
                self.driver.get(self.objSuite.ebay_url)
                self.robot_env.log_to_console("==========================================")
                wait = WebDriverWait(self.driver, 10)
                wait.until(EC.element_to_be_clickable((By.XPATH, self.objSuite.search_br)))


        except Exception as e:
            self.robot_env.log_to_console("ERROR LOADING EBAY WEBSITE" , str(e))
            logger.info("\t <b><h2>     ERROR LOADING EBAY WEBSITE : %s </h2></b>" % html_fail, html=True)
            time.sleep(3)
            self.driver.close()


    def test(self):
        self.commonobj.product_search_chrome()
        self.commonobj.choose_category_chrome()
        self.commonobj.select_product_chrome()
        self.commonobj.product_detail_page_chrome()
        self.commonobj.validate_condition_parameter_chrome()
        self.commonobj.checkout_Page_validation_chrome()
        self.commonobj.product_detail_validation_chrome()

    def cleanup(self):
        self.driver.close()