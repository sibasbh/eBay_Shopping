import re
import ast
import os
import yaml
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from robot.libraries.BuiltIn import BuiltIn
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC


class TestSuite(object):
    def __init__(self, testcasenum="000"):
        robot_env = BuiltIn()
        self.status = False

        self.ebay_url = robot_env.get_variable_value('${ebayLandingPage.url}')

        self.search_br = robot_env.get_variable_value('${ebayLandingPage.Searchbar}')
        self.result_kw = robot_env.get_variable_value('${ebayLandingPage.results_kw}')
        self.ebay_logo = robot_env.get_variable_value('${ebayLandingPage.ebay_logo}')


        self.cond_value = robot_env.get_variable_value('${ebayProductdetails.Conditionvalue}')
        self.price_value = robot_env.get_variable_value('${ebayProductdetails.Pricevalue}')
        self.prod_name = robot_env.get_variable_value('${ebayProductdetails.producename}')
        self.sellinfo_proddetail = robot_env.get_variable_value('${ebayProductdetails.SellerInformationvalue}')
        self.add_cart = robot_env.get_variable_value('${ebayProductdetails.AddtoCart}')


        self.prot_plan = robot_env.get_variable_value('${ebayProtectionPlan.ProtectionPlanPopup}')
        self.thank_btn = robot_env.get_variable_value('${ebayProtectionPlan.NoThanksbutton}')


        self.ck_title = robot_env.get_variable_value('${ebayShoppingcart.chekout_title}')
        self.cond_value1 = robot_env.get_variable_value('${ebayShoppingcart.Conditionvalue}')
        self.price_value1 = robot_env.get_variable_value('${ebayShoppingcart.Pricevalue}')
        self.prod_name1 = robot_env.get_variable_value('${ebayShoppingcart.producename}')
        self.sellinfo_shopcart = robot_env.get_variable_value('${ebayShoppingcart.SellerInformationvalue}')


        self.search_item = robot_env.get_variable_value("${Testcases.TC_ebay_Productsearch_%s.Searchitem}" % (testcasenum))
        self.nxt_btn = robot_env.get_variable_value("${Testcases.TC_ebay_Productsearch_%s.next_btn}" % (testcasenum))
        self.inch_search = robot_env.get_variable_value("${Testcases.TC_ebay_Productsearch_%s.inch_search}" % (testcasenum))
        self.itm_list = robot_env.get_variable_value("${Testcases.TC_ebay_Productsearch_%s.itemList}" % (testcasenum))



    def suite_setup(self):
        pass

    def suite_cleanup(self):
        pass

